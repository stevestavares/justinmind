(function(window, undefined) {

  var jimLinks = {
    "373db573-4daa-4a97-b4f6-5f8c37e0b9e5" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "373db573-4daa-4a97-b4f6-5f8c37e0b9e5"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);